package com.cineverse.entity.enums;

public enum EventVertical {
    EVENT, SPORTS, PLAY, ACTIVITY
}
