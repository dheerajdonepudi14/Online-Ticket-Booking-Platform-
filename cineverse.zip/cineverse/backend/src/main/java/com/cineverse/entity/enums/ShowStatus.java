package com.cineverse.entity.enums;

public enum ShowStatus {
    SCHEDULED, CANCELLED, COMPLETED
}
