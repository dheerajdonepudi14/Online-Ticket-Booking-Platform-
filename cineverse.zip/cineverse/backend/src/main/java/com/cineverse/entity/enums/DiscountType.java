package com.cineverse.entity.enums;

public enum DiscountType {
    PERCENT, FLAT
}
