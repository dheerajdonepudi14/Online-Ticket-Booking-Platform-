package com.cineverse.entity.enums;

public enum EventStatus {
    DRAFT, PUBLISHED, CANCELLED
}
