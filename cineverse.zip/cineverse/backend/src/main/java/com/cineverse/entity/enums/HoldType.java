package com.cineverse.entity.enums;

public enum HoldType {
    CHECKOUT, PAY_AT_VENUE
}
