package com.cineverse.entity.enums;

public enum TicketStatus {
    VALID, USED, CANCELLED, EXPIRED
}
