package com.cineverse.entity.enums;

public enum ReviewStatus {
    PENDING, APPROVED, REJECTED
}
