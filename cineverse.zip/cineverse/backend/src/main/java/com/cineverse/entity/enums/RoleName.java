package com.cineverse.entity.enums;

public enum RoleName {
    USER, ADMIN, PARTNER, VENUE_STAFF
}
