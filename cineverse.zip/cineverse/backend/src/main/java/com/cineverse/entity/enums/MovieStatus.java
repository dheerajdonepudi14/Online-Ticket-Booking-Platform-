package com.cineverse.entity.enums;

public enum MovieStatus {
    NOW_SHOWING, COMING_SOON, ARCHIVED
}
