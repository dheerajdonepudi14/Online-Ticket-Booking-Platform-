package com.cineverse.entity.enums;

public enum FavoriteType {
    MOVIE, CINEMA, EVENT
}
