package com.cineverse.entity.enums;

public enum NotificationType {
    BOOKING_CONFIRMED, PAYMENT_SUCCESS, PAYMENT_FAILED, SHOW_REMINDER, CANCELLATION, REFUND, PROMOTION
}
