package com.cineverse.entity.enums;

public enum BookingType {
    MOVIE, EVENT
}
