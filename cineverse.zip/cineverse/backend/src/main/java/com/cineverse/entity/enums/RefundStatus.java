package com.cineverse.entity.enums;

public enum RefundStatus {
    REQUESTED, PROCESSING, COMPLETED, FAILED
}
