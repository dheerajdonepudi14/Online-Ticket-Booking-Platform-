package com.cineverse.entity.enums;

public enum SeatLockStatus {
    ACTIVE, EXPIRED, RELEASED, CONSUMED
}
