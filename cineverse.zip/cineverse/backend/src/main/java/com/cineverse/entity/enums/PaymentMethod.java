package com.cineverse.entity.enums;

public enum PaymentMethod {
    CARD, UPI, GPAY, PHONEPE, NETBANKING, WALLET, PAY_AT_VENUE
}
