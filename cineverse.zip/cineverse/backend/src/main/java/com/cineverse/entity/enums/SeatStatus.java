package com.cineverse.entity.enums;

public enum SeatStatus {
    AVAILABLE, LOCKED, BOOKED, BLOCKED
}
