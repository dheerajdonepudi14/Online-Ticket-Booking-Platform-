package com.cineverse.entity.enums;

public enum PaymentProviderType {
    MOCK, STRIPE, RAZORPAY, PHONEPE, VENUE
}
