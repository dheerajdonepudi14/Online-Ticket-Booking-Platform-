-- Creates the database used by the backend integration tests (mvn test).
-- The application schema itself is created by Flyway, never by hand.
CREATE DATABASE cineverse_test;
